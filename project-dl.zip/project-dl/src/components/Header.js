import React from 'react';
import logo from '../assets/logo.png';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header className="app-header">
      <div className="logo">
        <img src={logo} alt="Logo" className="logo-img" />
        <span className="logo-text">Nada Gitar <span className="highlight">Akustik</span></span>
      </div>
      <nav>
        <Link to="/" className="nav-link">Home</Link>
        <Link to="/check" className="nav-link">Periksa Nada</Link>
      </nav>
    </header>
  );
}

export default Header;
