import React, { useRef, useState } from 'react';
import guitarImg from '../assets/guitar-head.png';

function CheckTone() {
  const fileInputRef = useRef(null);
  const [fileName, setFileName] = useState('');

  const handleUploadClick = () => {
    fileInputRef.current.click(); // membuka dialog file saat tombol diklik
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setFileName(file.name);
      // Di sini kamu bisa proses file seperti mengirim ke server atau validasi
      console.log('File uploaded:', file);
    }
  };

  return (
    <main className="check-content">
      <button className="button" onClick={handleUploadClick}>
        Upload From Computer
      </button>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
      {fileName && <p style={{ color: '#f5c518', marginTop: '10px' }}>Uploaded: {fileName}</p>}

      <div className="or-text">OR</div>
      <button className="button">Listen Now</button>
      <img src={guitarImg} alt="Guitar Head" className="guitar-img" />
    </main>
  );
}

export default CheckTone;
