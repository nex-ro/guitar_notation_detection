import React from 'react';
import logo from '../assets/logo.png';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <main className="home-content">
      <p className="subtext">I help you understand</p>
      <h2 className="main-title">
        <img src={logo} alt="logo kecil" className="icon-small" />
        <span className="highlight">Guitar Note</span>
      </h2>
      <p className="desc">hotter than ever</p>
      <Link to="/check">
        <button className="check-btn">Check Now</button>
      </Link>
    </main>
  );
}

export default Home;
